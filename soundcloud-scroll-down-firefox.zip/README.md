# soundcloud-scroll-down-firefox
This extension allows the user to scroll down the page automatically to posts by selecting desired date.
